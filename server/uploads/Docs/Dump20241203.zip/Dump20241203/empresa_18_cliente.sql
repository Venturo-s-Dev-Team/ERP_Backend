-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: empresa_18
-- ------------------------------------------------------
-- Server version	8.0.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `cliente`
--

DROP TABLE IF EXISTS `cliente`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cliente` (
  `id` int NOT NULL AUTO_INCREMENT,
  `razao_social` varchar(255) DEFAULT NULL,
  `nome_fantasia` varchar(255) DEFAULT NULL,
  `logradouro` varchar(255) DEFAULT NULL,
  `bairro` varchar(100) DEFAULT NULL,
  `cidade` varchar(100) DEFAULT NULL,
  `cep` varchar(10) DEFAULT NULL,
  `uf` varchar(2) DEFAULT NULL,
  `endereco` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `autorizados` text,
  `observacoes` text,
  `dia_para_faturamento` datetime DEFAULT NULL,
  `funcionario` text,
  `ramo_atividade` varchar(255) DEFAULT NULL,
  `limite` decimal(10,2) DEFAULT NULL,
  `site` varchar(255) DEFAULT NULL,
  `ativo` enum('SIM','NÃO') DEFAULT NULL,
  `cpf_cnpj` varchar(18) DEFAULT NULL,
  `ie` varchar(20) DEFAULT NULL,
  `telefone` varchar(20) DEFAULT NULL,
  `celular` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cliente`
--

LOCK TABLES `cliente` WRITE;
/*!40000 ALTER TABLE `cliente` DISABLE KEYS */;
INSERT INTO `cliente` VALUES (1,'Consumidor','','','','','','','','','','',NULL,'','',NULL,'','SIM','','','',''),(2,'Gabriela Mendes',NULL,'Avenida Doutor Antônio Lobo','Centro','Americana','13465-005','SP','Avenida Doutor Antônio Lobo, Americana/SP','mendes@gmail.com','NÃO','Ótima cliente, pode ceder 5% de desconto nos pedidos.','2024-12-05 00:00:00',NULL,NULL,2350.00,NULL,'SIM','213.123.123-12',NULL,'(21)31231-2312',NULL),(3,'Fidel Lopes Guanabara','Concessionária Guanabara','Avenida Comendador Thomaz Fortunato','Chácara Mantovani','Americana','13475-256','SP','Avenida Comendador Thomaz Fortunato, 450','guanabara@gmail.com','SIM','Apenas Lucas e Fidel podem receber os produtos dos pedidos, na entrega destes. É necessário enviar a nota fiscal junto do pedido.','2025-01-07 00:00:00','Lucas Ferraz de Alcântara, Fidel de Fortunato Dias','Comercial',50000.00,NULL,'SIM','23.912.391/2391-23','210.412.831.283','(19)92289-3209',NULL);
/*!40000 ALTER TABLE `cliente` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-12-03 20:12:33
