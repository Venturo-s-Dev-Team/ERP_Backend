-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: empresa_18
-- ------------------------------------------------------
-- Server version	8.0.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `historicologs`
--

DROP TABLE IF EXISTS `historicologs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `historicologs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `user_name` varchar(255) NOT NULL,
  `action` varchar(255) NOT NULL,
  `table_name` varchar(255) NOT NULL,
  `timestamp` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=85 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `historicologs`
--

LOCK TABLES `historicologs` WRITE;
/*!40000 ALTER TABLE `historicologs` DISABLE KEYS */;
INSERT INTO `historicologs` VALUES (1,18,'Marcos','Login','erp.cadastro_empresarial','2024-11-28 23:50:13'),(2,18,'Marcos','Cadastrou um funcionário com o nome: Bernardo, e com o cargo de Financeiro','empresa_18.funcionario','2024-11-28 23:54:53'),(3,18,'Marcos','Logout','empresa_18.funcionario','2024-11-29 00:02:04'),(4,18,'Marcos','Logout','empresa_18.funcionario','2024-11-29 00:02:04'),(5,18,'Marcos','Login','erp.cadastro_empresarial','2024-11-29 00:47:13'),(6,18,'Marcos','Login','erp.cadastro_empresarial','2024-11-29 01:35:09'),(7,18,'Marcos','Login','erp.cadastro_empresarial','2024-12-02 18:42:26'),(8,18,'Marcos','Registrou um produto com o nome: Pneu Goodyear','empresa_18.estoque','2024-12-02 18:48:49'),(9,18,'Marcos','Registrou um produto com o nome: Calota de prata de grid','empresa_18.estoque','2024-10-02 18:55:50'),(10,18,'Marcos','Registrou um produto com o nome: Radio eletrônico Lelong','empresa_18.estoque','2024-12-02 18:59:46'),(11,18,'Marcos','Venda efetuada para Consumidor','empresa_18.venda','2023-12-02 19:08:36'),(12,18,'Marcos','Venda efetuada para Consumidor','empresa_18.venda','2024-12-02 19:09:49'),(13,18,'Marcos','Registrou uma receita com o nome: Lava Jato','empresa_18.receitas','2024-12-02 19:16:50'),(14,18,'Marcos','Registrou uma despesa com o nome: Produtos de limpeza','empresa_18.despesas','2024-12-02 19:19:27'),(15,18,'Marcos','Registrou uma despesa com o nome: Bernardo','empresa_18.despesas','2024-12-02 19:31:15'),(16,18,'Marcos','Cadastrou um fornecedor no sistema com o nome Manoel Fernandes','empresa_18.fornecedor','2024-12-02 21:04:25'),(17,18,'Marcos','Cadastrou um cliente no sistema com o nome Gabriela Mendes','empresa_18.cliente','2024-12-02 21:06:46'),(18,18,'Marcos','Atualizou um cliente no sistema com o ID 2','empresa_18.cliente','2024-12-02 21:09:11'),(19,18,'Marcos','Logout','empresa_18.funcionario','2024-12-02 22:59:52'),(20,18,'Marcos','Logout','empresa_18.funcionario','2024-12-02 22:59:52'),(21,18,'Marcos','Login','erp.cadastro_empresarial','2024-12-02 23:31:20'),(22,18,'Marcos','Atualizou as informações do funcionário (1)','empresa_18.funcionario','2024-12-02 23:31:45'),(23,18,'Marcos','Cadastrou um funcionário com o nome: Amanda Nunes, e com o cargo de Gerente','empresa_18.funcionario','2024-12-02 23:33:06'),(24,18,'Marcos','Atualizou a senha do funcionário (2)','empresa_18.funcionario','2024-12-02 23:57:15'),(25,18,'Marcos','Cadastrou um funcionário com o nome: Cido Fernando, e com o cargo de Estoque','empresa_18.funcionario','2024-12-02 23:58:02'),(26,18,'Marcos','Cadastrou um funcionário com o nome: Josué Daniel, e com o cargo de Venda','empresa_18.funcionario','2024-12-02 23:59:23'),(27,18,'Marcos','Cadastrou um funcionário com o nome: Pedro Felipe, e com o cargo de Caixa','empresa_18.funcionario','2024-12-02 23:59:56'),(28,18,'Marcos','Atualizou as informações do funcionário (1)','empresa_18.funcionario','2024-12-03 00:00:20'),(29,18,'Marcos','Atualizou a senha do funcionário (1)','empresa_18.funcionario','2024-12-03 00:00:46'),(30,18,'Marcos','Logout','empresa_18.funcionario','2024-12-03 00:01:03'),(31,18,'Marcos','Logout','empresa_18.funcionario','2024-12-03 00:01:03'),(32,4,'Josué Daniel','Login','Funcionario','2024-12-03 00:01:14'),(33,4,'Josué Daniel','Login','Funcionario','2024-12-03 00:03:49'),(34,4,'Josué Daniel','Login','Funcionario','2024-12-03 00:07:12'),(35,4,'Josué Daniel','Login','Funcionario','2024-12-03 00:22:58'),(36,4,'Josué Daniel','Atualizou o pedido de número 5','empresa_18.venda','2024-12-03 00:38:38'),(37,4,'Josué Daniel','Cancelou um pedido no sistema com o id 4','empresa_18.venda','2024-12-03 00:38:56'),(38,4,'Josué Daniel','Logout','empresa_18.funcionario','2024-12-03 00:47:08'),(39,4,'Josué Daniel','Logout','empresa_18.funcionario','2024-12-03 00:47:08'),(40,18,'Marcos','Login','erp.cadastro_empresarial','2024-12-03 00:47:15'),(41,18,'Marcos','Logout','empresa_18.funcionario','2024-12-03 01:35:33'),(42,18,'Marcos','Logout','empresa_18.funcionario','2024-12-03 01:35:33'),(43,18,'Marcos','Login','erp.cadastro_empresarial','2024-12-03 01:45:52'),(44,18,'Marcos','Logout','empresa_18.funcionario','2024-12-03 01:59:40'),(45,18,'Marcos','Logout','empresa_18.funcionario','2024-12-03 01:59:40'),(46,18,'Marcos','Login','erp.cadastro_empresarial','2024-12-03 19:14:32'),(47,18,'Marcos','Atualizou as informações do funcionário (1)','empresa_18.funcionario','2024-12-03 19:45:03'),(48,18,'Marcos','Logout','empresa_18.funcionario','2024-12-03 20:08:22'),(49,18,'Marcos','Logout','empresa_18.funcionario','2024-12-03 20:08:22'),(50,18,'Marcos','Login','erp.cadastro_empresarial','2024-12-03 20:08:28'),(51,18,'Marcos','Login','erp.cadastro_empresarial','2024-12-03 20:08:41'),(52,18,'Marcos','Logout','empresa_18.funcionario','2024-12-03 20:47:38'),(53,18,'Marcos','Logout','empresa_18.funcionario','2024-12-03 20:47:38'),(54,18,'Marcos','Venda efetuada para Consumidor','empresa_18.venda','2024-12-03 20:48:05'),(55,18,'Marcos','Login','erp.cadastro_empresarial','2024-12-03 21:04:42'),(56,18,'Marcos','Atualizou um pagamento de número 1','empresa_18.despesas','2024-12-03 21:16:05'),(57,18,'Marcos','Atualizou as informações do funcionário (5)','empresa_18.funcionario','2024-12-03 21:20:32'),(58,18,'Marcos','Logout','empresa_18.funcionario','2024-12-03 21:34:11'),(59,18,'Marcos','Logout','empresa_18.funcionario','2024-12-03 21:34:11'),(60,18,'Marcos','Login','erp.cadastro_empresarial','2024-12-03 21:36:54'),(61,18,'Marcos','Logout','empresa_18.funcionario','2024-12-03 21:37:38'),(62,18,'Marcos','Logout','empresa_18.funcionario','2024-12-03 21:37:38'),(63,18,'Marcos','Login','erp.cadastro_empresarial','2024-12-03 21:39:29'),(64,18,'Marcos','Cadastrou um funcionário com o nome: Ana Paula Baker, e com o cargo de Financeiro','empresa_18.funcionario','2024-12-03 21:52:37'),(65,18,'Marcos','Cancelou um pedido no sistema com o id 6','empresa_18.venda','2024-12-03 21:56:43'),(66,18,'Marcos','Atualizou uma receita com o id: 3','empresa_18.receitas','2024-12-03 21:58:49'),(67,18,'Marcos','Atualizou uma receita (3)','empresa_18.receitas','2024-12-03 21:58:49'),(68,18,'Marcos','Atualizou uma receita com o id: 3','empresa_18.receitas','2024-12-03 21:58:54'),(69,18,'Marcos','Atualizou uma receita (3)','empresa_18.receitas','2024-12-03 21:58:54'),(70,18,'Marcos','Cadastrou um cliente no sistema com o nome Fidel Lopes Guanabara','empresa_18.cliente','2024-12-03 22:14:59'),(71,18,'Marcos','Registrou um produto com o nome: Filtro Ar Condicionado Cabine Hb20 Hb20s 2012 Em Diante Ix35','empresa_18.estoque','2024-12-03 22:18:40'),(72,1,'Bernardo','Login','Funcionario','2024-12-03 22:36:07'),(73,1,'Bernardo','Registrou uma despesa com o nome: Produtos de limpeza','empresa_18.despesas','2024-12-03 22:43:00'),(74,1,'Bernardo','Registrou uma despesa com o nome: Aluguel da Concessionária','empresa_18.despesas','2024-12-03 22:45:39'),(75,1,'Bernardo','Atualizou uma despesa (3)','empresa_18.despesas','2024-12-03 22:46:43'),(76,1,'Bernardo','Logout','empresa_18.funcionario','2024-12-03 22:50:42'),(77,1,'Bernardo','Logout','empresa_18.funcionario','2024-12-03 22:50:42'),(78,18,'Marcos','Login','erp.cadastro_empresarial','2024-12-03 22:50:50'),(79,18,'Marcos','Cadastrou um funcionário com o nome: Mirela Fonseca Lima, e com o cargo de Caixa','empresa_18.funcionario','2024-12-03 22:53:11'),(80,18,'Marcos','Logout','empresa_18.funcionario','2024-12-03 22:53:13'),(81,18,'Marcos','Logout','empresa_18.funcionario','2024-12-03 22:53:13'),(82,7,'Mirela Fonseca Lima','Login','Funcionario','2024-12-03 22:53:23'),(83,7,'Mirela Fonseca Lima','Logout','empresa_18.funcionario','2024-12-03 23:06:32'),(84,7,'Mirela Fonseca Lima','Logout','empresa_18.funcionario','2024-12-03 23:06:32');
/*!40000 ALTER TABLE `historicologs` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-12-03 20:12:32
