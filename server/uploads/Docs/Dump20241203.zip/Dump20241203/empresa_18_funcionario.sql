-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: empresa_18
-- ------------------------------------------------------
-- Server version	8.0.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `funcionario`
--

DROP TABLE IF EXISTS `funcionario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `funcionario` (
  `id` int NOT NULL AUTO_INCREMENT,
  `Nome` varchar(255) NOT NULL,
  `Senha` varchar(255) DEFAULT NULL,
  `emailPessoal` varchar(255) DEFAULT NULL,
  `cpf` varchar(15) DEFAULT NULL,
  `TypeUser` varchar(50) DEFAULT NULL,
  `email` varchar(255) NOT NULL,
  `DataInserimento` datetime DEFAULT CURRENT_TIMESTAMP,
  `Empresa` int DEFAULT '18',
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `funcionario`
--

LOCK TABLES `funcionario` WRITE;
/*!40000 ALTER TABLE `funcionario` DISABLE KEYS */;
INSERT INTO `funcionario` VALUES (1,'Bernardo','$2b$10$Uj9RUsQ2mFpvRFgZo6EEp.fPpoFxLjj/TiG0nw79CpyQ5oYb7KMYO','ewfew@wefr.com','132.131.232-32','Financeiro','bernardo@venturo.com','2024-11-28 23:54:53',18),(2,'Amanda Nunes','$2b$10$kbJ8H0zaKpI0U3akg7JKdehfSov5uDT4Z/EQCydByZ8phFnZ6sPmu','amanda@office.com','214.142.424-25','Gerente','amanda.nunes@venturo.com','2024-12-02 23:33:06',18),(3,'Cido Fernando','$2b$10$zhY4jCavqlfsFvZijVaZzOkFYROM6JNAg65WAqafIO/Anvr2yKDGG','cido@yahoo.com','242.343.242-33','Estoque','cido.fernando@venturo.com','2024-12-02 23:58:02',18),(4,'Josué Daniel','$2b$10$slgaj9gn6H56PEiEnVWoXOE8LVIUciOBHlqPaEIQWk5EW2Z7nu0Fa','jo@uol.com','123.122.123-21','Venda','josué.daniel@venturo.com','2024-12-02 23:59:23',18),(5,'Pedro Felipe','$2b$10$jm9id01rdYRs72OEOW/wMuyYauKfov/lhRGy47CEuNODFsmKEx3xm','ped@uol.com','123.123.124-42','Caixa','pedro.felipe@venturo.com','2024-12-02 23:59:56',18),(6,'Ana Paula Baker','$2b$10$GdbWPzI3Qj76g8Jn8yafFuTD/zUcOXEMjfgKmGx8OhhYKgOoq2mk2','baker@gmail.com','213.213.123-21','Financeiro','ana.paula.baker@venturo.com','2024-12-03 21:52:37',18),(7,'Mirela Fonseca Lima','$2b$10$9I43NkiVHKBtr6D/TTAvoe.L1p1YT09UT0oIT3dF7x7mS4DxHkVHC','lima@mail.com','320.423.943-04','Caixa','mirela.fonseca.lima@venturo.com','2024-12-03 22:53:11',18);
/*!40000 ALTER TABLE `funcionario` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-12-03 20:12:34
