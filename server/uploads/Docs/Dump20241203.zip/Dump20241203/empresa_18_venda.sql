-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: empresa_18
-- ------------------------------------------------------
-- Server version	8.0.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `venda`
--

DROP TABLE IF EXISTS `venda`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `venda` (
  `id_venda` int DEFAULT NULL,
  `id_pedido` int NOT NULL AUTO_INCREMENT,
  `nome_cliente` varchar(100) DEFAULT NULL,
  `cpf_cnpj` varchar(18) DEFAULT NULL,
  `produto` text,
  `desconto` decimal(10,2) DEFAULT NULL,
  `forma_pagamento` varchar(50) DEFAULT NULL,
  `total` decimal(10,2) DEFAULT NULL,
  `garantia` varchar(50) DEFAULT NULL,
  `vendedor` varchar(100) DEFAULT NULL,
  `Status` varchar(15) DEFAULT 'EM ABERTO',
  `Data` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_pedido`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `venda`
--

LOCK TABLES `venda` WRITE;
/*!40000 ALTER TABLE `venda` DISABLE KEYS */;
INSERT INTO `venda` VALUES (1,1,'Consumidor','123.264.987-20','[{\"Codigo\":3,\"Nome\":\"Radio eletrônico Lelong\",\"Quantidade\":15,\"ValorUnitario\":\"220.00\",\"Fornecedor\":\"Mercado Livre\",\"Tamanho\":\"260 W\",\"Imagem\":\"1733165986219-Radio.png\",\"Estoque\":0,\"quantidade\":1},{\"Codigo\":2,\"Nome\":\"Calota de prata de grid\",\"Quantidade\":37,\"ValorUnitario\":\"86.00\",\"Fornecedor\":\"Grid linea\",\"Tamanho\":\"Aro 14\",\"Imagem\":\"1733165750753-Aros.png\",\"Estoque\":0,\"quantidade\":4}]',5.00,'À vista',535.80,NULL,'Marcos','VENDA CONCLUÍDA','2024-12-02 19:03:10'),(2,2,'Consumidor','309.933.234-39','[{\"Codigo\":1,\"Nome\":\"Pneu Goodyear\",\"Quantidade\":40,\"ValorUnitario\":\"550.00\",\"Fornecedor\":\"Goodyear\",\"Tamanho\":\"Aro 14\",\"Imagem\":\"1733165329618-Pneu-Aro-14-Goodyear-2-Touring-175-65R14-1760750.png\",\"Estoque\":0,\"quantidade\":4}]',5.00,'À vista',2090.00,NULL,'Marcos','VENDA CONCLUÍDA','2024-12-02 19:07:35'),(7,3,'Gabriela Mendes','213.123.123-12','[{\"Codigo\":3,\"Nome\":\"Radio eletrônico Lelong\",\"Quantidade\":14,\"ValorUnitario\":\"220.00\",\"Fornecedor\":\"Mercado Livre\",\"Tamanho\":\"260 W\",\"Imagem\":\"1733165986219-Radio.png\",\"Estoque\":0,\"quantidade\":4}]',5.00,'À vista',836.00,NULL,'Josué Daniel','VENDA CONCLUÍDA','2024-12-03 00:36:18'),(NULL,4,'Consumidor',NULL,'[{\"Codigo\":2,\"Nome\":\"Calota de prata de grid\",\"Quantidade\":33,\"ValorUnitario\":\"86.00\",\"Fornecedor\":\"Grid linea\",\"Tamanho\":\"Aro 14\",\"Imagem\":\"1733165750753-Aros.png\",\"Estoque\":0,\"quantidade\":4}]',0.00,NULL,344.00,NULL,'Josué Daniel','CANCELADA','2024-12-03 00:36:35'),(NULL,5,'Consumidor',NULL,'[{\"Codigo\":2,\"Nome\":\"Calota de prata de grid\",\"Quantidade\":29,\"ValorUnitario\":\"86.00\",\"Fornecedor\":\"Grid linea\",\"Tamanho\":\"Aro 14\",\"Imagem\":\"1733165750753-Aros.png\",\"Estoque\":0,\"quantidade\":4}]',5.00,NULL,326.80,NULL,'Josué Daniel','EM ABERTO','2024-12-03 00:36:52'),(NULL,6,'Gabriela Mendes',NULL,'[{\"Codigo\":3,\"Nome\":\"Radio eletrônico Lelong\",\"Quantidade\":10,\"ValorUnitario\":\"220.00\",\"Fornecedor\":\"Mercado Livre\",\"Tamanho\":\"260 W\",\"Imagem\":\"1733165986219-Radio.png\",\"Estoque\":0,\"quantidade\":1}]',0.00,NULL,220.00,NULL,'Josué Daniel','CANCELADA','2024-12-03 00:45:54'),(3,7,'Consumidor','42588517870','[{\"Codigo\":1,\"Nome\":\"Pneu Goodyear\",\"Quantidade\":36,\"ValorUnitario\":\"550.00\",\"Fornecedor\":\"Goodyear\",\"Tamanho\":\"Aro 14\",\"Imagem\":\"1733165329618-Pneu-Aro-14-Goodyear-2-Touring-175-65R14-1760750.png\",\"Estoque\":0,\"quantidade\":1}]',5.00,'À vista',522.50,NULL,'Marcos','VENDA CONCLUÍDA','2024-12-03 20:46:36');
/*!40000 ALTER TABLE `venda` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-12-03 20:12:31
